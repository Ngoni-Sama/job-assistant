var R=require("../../chunks/[turbopack]_runtime.js")("server/app/robots.txt/route.js")
R.c("server/chunks/[root-of-the-server]__1zipus3._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_robots_txt_route_actions_076nlqq.js")
R.m(96350)
module.exports=R.m(96350).exports
