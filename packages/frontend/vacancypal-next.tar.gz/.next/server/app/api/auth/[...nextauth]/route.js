var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/[...nextauth]/route.js")
R.c("server/chunks/[root-of-the-server]__1rzkze7._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_auth_[___nextauth]_route_actions_1ha-ivm.js")
R.m(26970)
module.exports=R.m(26970).exports
