var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pesepay/callback/route.js")
R.c("server/chunks/[root-of-the-server]__09t114c._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_pesepay_callback_route_actions_0u4-eig.js")
R.m(13013)
module.exports=R.m(13013).exports
