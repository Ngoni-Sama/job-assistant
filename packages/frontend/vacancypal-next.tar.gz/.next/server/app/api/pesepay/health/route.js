var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pesepay/health/route.js")
R.c("server/chunks/[root-of-the-server]__0smsxm3._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_pesepay_health_route_actions_1rg15h6.js")
R.m(48983)
module.exports=R.m(48983).exports
