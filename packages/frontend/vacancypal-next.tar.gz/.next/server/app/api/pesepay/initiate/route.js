var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pesepay/initiate/route.js")
R.c("server/chunks/[root-of-the-server]__1jce37j._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_pesepay_initiate_route_actions_0lztzo7.js")
R.m(24790)
module.exports=R.m(24790).exports
