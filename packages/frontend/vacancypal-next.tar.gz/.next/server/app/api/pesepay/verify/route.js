var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/pesepay/verify/route.js")
R.c("server/chunks/[root-of-the-server]__0mqbhrb._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_pesepay_verify_route_actions_1nle-mu.js")
R.m(85475)
module.exports=R.m(85475).exports
