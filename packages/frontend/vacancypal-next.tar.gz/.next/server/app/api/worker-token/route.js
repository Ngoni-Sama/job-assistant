var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/worker-token/route.js")
R.c("server/chunks/[root-of-the-server]__0n5kih_._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_worker-token_route_actions_0ioh033.js")
R.m(51639)
module.exports=R.m(51639).exports
