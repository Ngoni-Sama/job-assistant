var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gmail/send/route.js")
R.c("server/chunks/[root-of-the-server]__125w-t1._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_api_gmail_send_route_actions_1xeewio.js")
R.m(79736)
module.exports=R.m(79736).exports
