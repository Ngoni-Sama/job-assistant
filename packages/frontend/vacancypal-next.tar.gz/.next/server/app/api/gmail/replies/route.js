var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/gmail/replies/route.js")
R.c("server/chunks/[root-of-the-server]__093wcmm._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/[root-of-the-server]__0vsq17l._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_api_gmail_replies_route_actions_0dgovh2.js")
R.m(73786)
module.exports=R.m(73786).exports
