var R=require("../../chunks/[turbopack]_runtime.js")("server/app/llms.txt/route.js")
R.c("server/chunks/[root-of-the-server]__0b4013n._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_llms_txt_route_actions_1nefjps.js")
R.m(40149)
module.exports=R.m(40149).exports
