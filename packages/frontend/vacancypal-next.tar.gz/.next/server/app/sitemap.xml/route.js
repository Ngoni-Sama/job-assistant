var R=require("../../chunks/[turbopack]_runtime.js")("server/app/sitemap.xml/route.js")
R.c("server/chunks/[root-of-the-server]__0iqfjnc._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_sitemap_xml_route_actions_10wr9yn.js")
R.m(11980)
module.exports=R.m(11980).exports
