var R=require("../../chunks/[turbopack]_runtime.js")("server/app/manifest.webmanifest/route.js")
R.c("server/chunks/[externals]__1mn3361._.js")
R.c("server/chunks/_1t-bi6x._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_manifest_webmanifest_route_actions_1exi64w.js")
R.m(42217)
module.exports=R.m(42217).exports
