var R=require("../../chunks/[turbopack]_runtime.js")("server/app/opengraph-image.png/route.js")
R.c("server/chunks/[externals]__1mn3361._.js")
R.c("server/chunks/_106cjiy._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/0ysl_frontend__next-internal_server_app_opengraph-image_png_route_actions_0ydzycj.js")
R.m(34339)
module.exports=R.m(34339).exports
