var R=require("../../chunks/[turbopack]_runtime.js")("server/app/apple-icon.png/route.js")
R.c("server/chunks/[externals]__1mn3361._.js")
R.c("server/chunks/_0cj6qtf._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_apple-icon_png_route_actions_09t1nqa.js")
R.m(66336)
module.exports=R.m(66336).exports
