var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]__1mn3361._.js")
R.c("server/chunks/_1lelx7c._.js")
R.c("server/chunks/node_modules_next_1zc5q0a._.js")
R.c("server/chunks/[root-of-the-server]__15bjnu5._.js")
R.c("server/chunks/packages_frontend__next-internal_server_app_icon_png_route_actions_1lfdi_h.js")
R.m(92317)
module.exports=R.m(92317).exports
