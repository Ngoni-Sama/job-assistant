1:"$Sreact.fragment"
2:I[92246,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js","/_next/static/chunks/1rp7-6qwpvia2.js"],"DeleteAccount"]
3:I[22016,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js","/_next/static/chunks/1rp7-6qwpvia2.js"],""]
4:I[97367,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"OutletBoundary"]
5:"$Sreact.suspense"
9:I[97367,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"ViewportBoundary"]
a:I[97367,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"MetadataBoundary"]
8:X
24:X
24:C
0:{"buildId":"-dFRcQqkLBn4wqEqV0ivM","data":[{"rsc":["$","$1","c",{"children":[["$","article",null,{"className":"glass mx-auto max-w-3xl space-y-6 rounded-3xl p-6 text-gray-700 sm:p-10","children":[["$","header",null,{"children":[["$","h1",null,{"className":"text-3xl font-extrabold tracking-tight text-gray-900","children":"Delete your VacancyPal account"}],["$","p",null,{"className":"mt-1 text-sm text-gray-500","children":["Last updated: ","7 October 2026"]}]]}],[["$","p",null,{"className":"max-w-prose leading-relaxed","children":["You can delete your ","VacancyPal"," account at any time. Deletion is permanent and happens straight away."]}],["$","h2",null,{"className":"pt-2 text-lg font-bold text-gray-900","children":"Delete it now"}],["$","p",null,{"className":"max-w-prose leading-relaxed","children":["Sign in with the Google account you use for ","VacancyPal",", then confirm below."]}],["$","$L2",null,{}],["$","h2",null,{"className":"pt-2 text-lg font-bold text-gray-900","children":"Other ways"}],["$","ul",null,{"className":"list-disc space-y-1.5 pl-5 leading-relaxed","children":[["$","li","0",{"children":"In the VacancyPal app or on the website: Settings → Delete account."}],["$","li","1",{"children":"By email: write to support@vacancypal.co.zw from the address on your account and ask us to delete it. We do it within 7 days and confirm by email."}]]}],["$","h2",null,{"className":"pt-2 text-lg font-bold text-gray-900","children":"What gets deleted"}],["$","ul",null,{"className":"list-disc space-y-1.5 pl-5 leading-relaxed","children":[["$","li","0",{"children":"Your profile, availability and job preferences"}],["$","li","1",{"children":"Your CVs and uploaded CV files, and your place in employer talent search"}],["$","li","2",{"children":"Your applications, saved and swiped jobs, and Quick Match history"}],["$","li","3",{"children":"Your messages and conversations with employers (or candidates)"}],["$","li","4",{"children":"Your credit balance, notification devices, and Google sign-in permissions held by us"}],["$","li","5",{"children":"Employer accounts: your company profile and verification documents"}]]}],["$","h2",null,{"className":"pt-2 text-lg font-bold text-gray-900","children":"What we keep"}],["$","p",null,{"className":"max-w-prose leading-relaxed","children":"Records of payments you made (amount, date, reference) — the law requires us to keep these for accounting for up to 7 years. They don’t include your CV or profile. Applications you already sent from your Gmail stay in your own Gmail and with the employers you sent them to; we can’t delete those."}],["$","p",null,{"className":"max-w-prose leading-relaxed","children":["Questions? See our ",["$","$L3",null,{"href":"/privacy","className":"font-medium text-brand-700 underline","children":"Privacy Policy"}]," or email ","support@vacancypal.co.zw","."]}]]]}],[["$","script","script-0",{"src":"/_next/static/chunks/1rp7-6qwpvia2.js","async":true}]],["$","$L4",null,{"children":["$","$5",null,{"name":"Next.MetadataOutlet","children":"$@6"}]}]]}],"isPartial":"$@7","staleTime":"$8","varyParams":null},{"rsc":["$","$1","h",{"children":[null,["$","$L9",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}],["$","meta","2",{"name":"theme-color","content":"#0048c8"}]]}],["$","div",null,{"hidden":true,"children":["$","$La",null,{"children":["$","$5",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Delete your account · VacancyPal"}],["$","meta","1",{"name":"description","content":"How to delete your VacancyPal account and all the data stored with it — in the app, on the website, or by email."}],["$","meta","2",{"name":"application-name","content":"VacancyPal"}],["$","link","3",{"rel":"manifest","href":"/manifest.webmanifest"}],["$","meta","4",{"name":"keywords","content":"jobs in Zimbabwe,Zimbabwe vacancies,Harare jobs,Bulawayo jobs,ATS CV,CV builder,job applications,VacancyPal"}],["$","meta","5",{"name":"creator","content":"VacancyPal"}],["$","meta","6",{"name":"publisher","content":"VacancyPal"}],"$Lb","$Lc","$Ld","$Le","$Lf","$L10","$L11","$L12","$L13","$L14","$L15","$L16","$L17","$L18","$L19","$L1a","$L1b","$L1c","$L1d","$L1e","$L1f"]}]}]}],"$L20"]}],"isPartial":"$@21","staleTime":"$8","varyParams":null},{"rsc":"$L22","isPartial":"$@23","staleTime":"$8","varyParams":"$24"}],"isUpgradeableISRFallback":false,"a":"$@25","rootVaryParams":null,"needsRuntimeRequest":"$@26"}
27:I[27201,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"IconMark"]
28:I[39756,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"default"]
29:I[37457,["/_next/static/chunks/41a5s6zaul_ut.js","/_next/static/chunks/2ceovzf2hv6-b.js","/_next/static/chunks/15-j39s_-62be.js"],"default"]
6:null
b:["$","meta","7",{"name":"robots","content":"index, follow"}]
c:["$","meta","8",{"name":"googlebot","content":"index, follow, max-image-preview:large, max-snippet:-1"}]
d:["$","link","9",{"rel":"canonical","href":"https://vacancypal.co.zw/delete-account"}]
e:["$","meta","10",{"name":"format-detection","content":"telephone=no"}]
f:["$","meta","11",{"property":"og:title","content":"Delete your account · VacancyPal"}]
10:["$","meta","12",{"property":"og:description","content":"How to delete your VacancyPal account and all the data stored with it — in the app, on the website, or by email."}]
11:["$","meta","13",{"property":"og:url","content":"https://vacancypal.co.zw/delete-account"}]
12:["$","meta","14",{"property":"og:site_name","content":"VacancyPal"}]
13:["$","meta","15",{"property":"og:locale","content":"en_ZW"}]
14:["$","meta","16",{"property":"og:image","content":"https://vacancypal.co.zw/opengraph-image.png"}]
15:["$","meta","17",{"property":"og:image:width","content":"1200"}]
16:["$","meta","18",{"property":"og:image:height","content":"630"}]
17:["$","meta","19",{"property":"og:image:alt","content":"VacancyPal — jobs in Zimbabwe"}]
18:["$","meta","20",{"property":"og:type","content":"website"}]
19:["$","meta","21",{"name":"twitter:card","content":"summary_large_image"}]
1a:["$","meta","22",{"name":"twitter:title","content":"Delete your account · VacancyPal"}]
1b:["$","meta","23",{"name":"twitter:description","content":"How to delete your VacancyPal account and all the data stored with it — in the app, on the website, or by email."}]
1c:["$","meta","24",{"name":"twitter:image","content":"https://vacancypal.co.zw/opengraph-image.png"}]
1d:["$","link","25",{"rel":"icon","href":"/icon.png?icon.002_5nmi_btgc.png","sizes":"256x256","type":"image/png"}]
1e:["$","link","26",{"rel":"apple-touch-icon","href":"/apple-icon.png?apple-icon.2wfbyn46knpls.png","sizes":"180x180","type":"image/png"}]
1f:["$","$L27","27",{}]
20:["$","meta",null,{"name":"next-size-adjust","content":""}]
22:["$","$1","c",{"children":[null,["$","$L28",null,{"parallelRouterKey":"children","template":["$","$L29",null,{}]}]]}]
26:true
8:300
8:C
25:0
21:"$undefined"
23:"$undefined"
7:"$undefined"
