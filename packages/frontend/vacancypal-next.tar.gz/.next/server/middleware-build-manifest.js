globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/f1HRXg7cFTw9BVr5PgGLO/_buildManifest.js",
    "static/f1HRXg7cFTw9BVr5PgGLO/_ssgManifest.js",
    "static/f1HRXg7cFTw9BVr5PgGLO/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/2mmpezlrfmbu5.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/2e_lrwr-bf1eq.js",
    "static/chunks/turbopack-0dqy9m8adz5px.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
