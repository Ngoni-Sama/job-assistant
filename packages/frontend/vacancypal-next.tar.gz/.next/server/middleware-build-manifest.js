globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/Qk5PJb0TmZsYWc3djSASz/_buildManifest.js",
    "static/Qk5PJb0TmZsYWc3djSASz/_ssgManifest.js",
    "static/Qk5PJb0TmZsYWc3djSASz/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/36ka9ojokzg64.js",
    "static/chunks/1mkbuudhndal5.js",
    "static/chunks/2e_lrwr-bf1eq.js",
    "static/chunks/turbopack-3n_jo-pnfv-7g.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
