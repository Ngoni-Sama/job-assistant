module.exports=[95274,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_api_pesepay_initiate_route_actions_0lztzo7.js.map