module.exports=[18791,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_manifest_webmanifest_route_actions_1exi64w.js.map