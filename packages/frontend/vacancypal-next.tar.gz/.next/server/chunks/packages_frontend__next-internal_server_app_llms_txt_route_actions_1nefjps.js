module.exports=[11950,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_llms_txt_route_actions_1nefjps.js.map