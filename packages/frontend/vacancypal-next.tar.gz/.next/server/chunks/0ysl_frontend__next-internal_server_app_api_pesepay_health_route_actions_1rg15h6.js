module.exports=[72087,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_api_pesepay_health_route_actions_1rg15h6.js.map