module.exports=[52087,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_api_pesepay_callback_route_actions_0u4-eig.js.map