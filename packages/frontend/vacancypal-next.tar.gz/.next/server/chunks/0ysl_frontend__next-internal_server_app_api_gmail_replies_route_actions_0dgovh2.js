module.exports=[45006,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_api_gmail_replies_route_actions_0dgovh2.js.map