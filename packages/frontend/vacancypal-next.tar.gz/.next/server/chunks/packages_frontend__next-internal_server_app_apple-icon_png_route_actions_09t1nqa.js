module.exports=[29541,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_apple-icon_png_route_actions_09t1nqa.js.map