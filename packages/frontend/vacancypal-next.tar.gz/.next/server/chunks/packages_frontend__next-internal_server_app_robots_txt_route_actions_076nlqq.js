module.exports=[2596,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_robots_txt_route_actions_076nlqq.js.map