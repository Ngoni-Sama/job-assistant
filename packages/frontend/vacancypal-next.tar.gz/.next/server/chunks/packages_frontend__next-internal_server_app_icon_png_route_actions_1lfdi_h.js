module.exports=[37222,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_icon_png_route_actions_1lfdi_h.js.map