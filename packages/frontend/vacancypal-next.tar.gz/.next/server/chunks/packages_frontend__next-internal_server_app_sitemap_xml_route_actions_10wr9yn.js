module.exports=[89924,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_sitemap_xml_route_actions_10wr9yn.js.map