module.exports=[35720,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_api_worker-token_route_actions_0ioh033.js.map