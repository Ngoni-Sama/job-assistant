module.exports=[46358,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Swipe candidates","/employers/swipe");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},56924,function(a){a.n(a.i(46358))}];

//# sourceMappingURL=packages_frontend_src_app_employers_swipe_layout_tsx_0_-9-4s._.js.map