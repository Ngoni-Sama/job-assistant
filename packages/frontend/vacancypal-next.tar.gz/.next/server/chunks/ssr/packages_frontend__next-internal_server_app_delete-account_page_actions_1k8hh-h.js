module.exports=[85309,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_delete-account_page_actions_1k8hh-h.js.map