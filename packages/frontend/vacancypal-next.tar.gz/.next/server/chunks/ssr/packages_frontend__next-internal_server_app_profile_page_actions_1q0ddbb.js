module.exports=[65772,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_profile_page_actions_1q0ddbb.js.map