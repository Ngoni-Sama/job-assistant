module.exports=[58236,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Quick Match","/quick-match");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},74509,function(a){a.n(a.i(58236))}];

//# sourceMappingURL=packages_frontend_src_app_quick-match_layout_tsx_02izxvd._.js.map