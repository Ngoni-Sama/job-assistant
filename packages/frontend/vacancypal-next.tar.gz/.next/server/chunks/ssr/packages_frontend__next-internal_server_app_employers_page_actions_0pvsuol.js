module.exports=[37685,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_employers_page_actions_0pvsuol.js.map