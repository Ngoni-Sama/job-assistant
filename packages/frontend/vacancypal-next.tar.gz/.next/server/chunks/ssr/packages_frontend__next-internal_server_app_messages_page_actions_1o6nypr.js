module.exports=[50444,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_messages_page_actions_1o6nypr.js.map