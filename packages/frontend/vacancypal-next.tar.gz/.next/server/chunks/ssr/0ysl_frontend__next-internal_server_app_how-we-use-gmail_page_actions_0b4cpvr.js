module.exports=[14585,(a,b,c)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_how-we-use-gmail_page_actions_0b4cpvr.js.map