module.exports=[30127,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_pricing_page_actions_1wyi909.js.map