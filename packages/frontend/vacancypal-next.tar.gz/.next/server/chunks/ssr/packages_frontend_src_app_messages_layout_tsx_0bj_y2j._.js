module.exports=[559,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Messages","/messages");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},18743,function(a){a.n(a.i(559))}];

//# sourceMappingURL=packages_frontend_src_app_messages_layout_tsx_0bj_y2j._.js.map