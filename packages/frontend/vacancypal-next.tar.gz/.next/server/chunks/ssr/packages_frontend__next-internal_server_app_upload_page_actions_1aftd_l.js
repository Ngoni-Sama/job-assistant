module.exports=[33474,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_upload_page_actions_1aftd_l.js.map