module.exports=[42613,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_terms_page_actions_07yp3jb.js.map