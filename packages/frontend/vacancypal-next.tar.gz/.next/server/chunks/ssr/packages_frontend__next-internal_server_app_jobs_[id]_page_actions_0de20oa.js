module.exports=[91e3,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_jobs_%5Bid%5D_page_actions_0de20oa.js.map