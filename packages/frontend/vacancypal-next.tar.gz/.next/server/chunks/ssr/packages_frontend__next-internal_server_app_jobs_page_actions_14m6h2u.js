module.exports=[12567,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_jobs_page_actions_14m6h2u.js.map