module.exports=[79593,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_privacy_page_actions_18f6-1b.js.map