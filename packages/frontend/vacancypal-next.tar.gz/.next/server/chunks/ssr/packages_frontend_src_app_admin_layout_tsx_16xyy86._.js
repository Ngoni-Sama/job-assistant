module.exports=[49771,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Admin","/admin");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},26672,function(a){a.n(a.i(49771))}];

//# sourceMappingURL=packages_frontend_src_app_admin_layout_tsx_16xyy86._.js.map