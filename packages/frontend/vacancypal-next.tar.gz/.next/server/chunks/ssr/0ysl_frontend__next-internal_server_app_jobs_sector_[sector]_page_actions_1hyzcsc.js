module.exports=[54652,(a,b,c)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_jobs_sector_%5Bsector%5D_page_actions_1hyzcsc.js.map