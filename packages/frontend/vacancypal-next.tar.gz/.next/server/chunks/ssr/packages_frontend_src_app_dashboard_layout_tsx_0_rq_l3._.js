module.exports=[67175,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Dashboard","/dashboard");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},2586,function(a){a.n(a.i(67175))}];

//# sourceMappingURL=packages_frontend_src_app_dashboard_layout_tsx_0_rq_l3._.js.map