module.exports=[97471,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_dashboard_page_actions_1_7gt54.js.map