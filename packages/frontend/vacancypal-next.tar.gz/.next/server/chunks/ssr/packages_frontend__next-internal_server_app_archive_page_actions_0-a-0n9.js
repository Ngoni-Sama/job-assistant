module.exports=[88191,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_archive_page_actions_0-a-0n9.js.map