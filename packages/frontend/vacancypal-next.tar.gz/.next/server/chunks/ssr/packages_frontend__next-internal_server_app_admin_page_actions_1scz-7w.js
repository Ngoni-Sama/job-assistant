module.exports=[84883,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_admin_page_actions_1scz-7w.js.map