module.exports=[82476,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Find talent","/employers/search");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},24573,function(a){a.n(a.i(82476))}];

//# sourceMappingURL=packages_frontend_src_app_employers_search_layout_tsx_0yd5kv3._.js.map