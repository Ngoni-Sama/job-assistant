module.exports=[18646,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_quick-match_page_actions_1nnnqzw.js.map