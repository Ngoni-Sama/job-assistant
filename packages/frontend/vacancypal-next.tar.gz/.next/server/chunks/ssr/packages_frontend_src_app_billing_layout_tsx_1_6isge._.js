module.exports=[60094,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Credits & billing","/billing");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},10054,function(a){a.n(a.i(60094))}];

//# sourceMappingURL=packages_frontend_src_app_billing_layout_tsx_1_6isge._.js.map