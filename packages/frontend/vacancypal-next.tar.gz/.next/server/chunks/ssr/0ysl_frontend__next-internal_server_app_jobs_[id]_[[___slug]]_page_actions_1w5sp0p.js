module.exports=[12245,(a,b,c)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_jobs_%5Bid%5D_%5B%5B___slug%5D%5D_page_actions_1w5sp0p.js.map