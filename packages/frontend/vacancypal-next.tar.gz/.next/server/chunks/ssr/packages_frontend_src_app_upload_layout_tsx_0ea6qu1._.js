module.exports=[32052,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Upload your CV","/upload");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},91187,function(a){a.n(a.i(32052))}];

//# sourceMappingURL=packages_frontend_src_app_upload_layout_tsx_0ea6qu1._.js.map