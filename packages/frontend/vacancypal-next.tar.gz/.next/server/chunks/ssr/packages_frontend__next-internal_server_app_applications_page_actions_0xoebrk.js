module.exports=[57686,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_applications_page_actions_0xoebrk.js.map