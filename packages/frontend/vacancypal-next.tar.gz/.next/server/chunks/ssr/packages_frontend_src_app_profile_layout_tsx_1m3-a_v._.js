module.exports=[14500,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("My profile","/profile");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},93,function(a){a.n(a.i(14500))}];

//# sourceMappingURL=packages_frontend_src_app_profile_layout_tsx_1m3-a_v._.js.map