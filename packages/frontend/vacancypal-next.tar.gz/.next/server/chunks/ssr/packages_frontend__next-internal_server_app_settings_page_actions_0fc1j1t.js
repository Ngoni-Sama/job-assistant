module.exports=[90482,(a,b,c)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_settings_page_actions_0fc1j1t.js.map