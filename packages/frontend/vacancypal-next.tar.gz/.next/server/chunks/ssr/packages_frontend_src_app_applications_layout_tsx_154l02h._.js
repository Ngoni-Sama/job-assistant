module.exports=[9113,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("My applications","/applications");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},50405,function(a){a.n(a.i(9113))}];

//# sourceMappingURL=packages_frontend_src_app_applications_layout_tsx_154l02h._.js.map