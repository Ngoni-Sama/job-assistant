module.exports=[14781,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Candidates","/employers/candidates");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},71852,function(a){a.n(a.i(14781))}];

//# sourceMappingURL=packages_frontend_src_app_employers_candidates_layout_tsx_1h8ckew._.js.map