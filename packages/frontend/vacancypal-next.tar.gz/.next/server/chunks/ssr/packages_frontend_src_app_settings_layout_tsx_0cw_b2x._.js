module.exports=[71463,a=>{"use strict";let b=(0,a.i(61650).privateMeta)("Settings","/settings");a.s(["default",0,function({children:a}){return a},"metadata",0,b])},36346,function(a){a.n(a.i(71463))}];

//# sourceMappingURL=packages_frontend_src_app_settings_layout_tsx_0cw_b2x._.js.map