module.exports=[63143,(e,o,d)=>{}];

//# sourceMappingURL=0ysl_frontend__next-internal_server_app_opengraph-image_png_route_actions_0ydzycj.js.map