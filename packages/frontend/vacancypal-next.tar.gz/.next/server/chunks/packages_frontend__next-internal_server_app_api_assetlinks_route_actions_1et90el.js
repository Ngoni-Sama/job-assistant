module.exports=[13319,(e,o,d)=>{}];

//# sourceMappingURL=packages_frontend__next-internal_server_app_api_assetlinks_route_actions_1et90el.js.map